  

    <!-- Docs nav
    ================================================== -->
    <div class="row">
      <div class="span3 bs-docs-sidebar">
        <ul class="nav nav-list bs-docs-sidenav">
          <li><a href="#download-bootstrap"><i class="icon-chevron-right"></i> Download</a></li>
          <li><a href="#file-structure"><i class="icon-chevron-right"></i> File structure</a></li>
          <li><a href="#contents"><i class="icon-chevron-right"></i> What's included</a></li>
          <li><a href="#html-template"><i class="icon-chevron-right"></i> HTML template</a></li>
          <li><a href="#examples"><i class="icon-chevron-right"></i> Examples</a></li>
          <li><a href="#what-next"><i class="icon-chevron-right"></i> What next?</a></li>
        </ul>
      </div>