<form class="form-search" action="/" method="get">
  <input type="text" name="s" id="search" value="<?php the_search_query(); ?>" class="input-medium search-query">
  <button type="submit" class="btn">Search</button>
</form>